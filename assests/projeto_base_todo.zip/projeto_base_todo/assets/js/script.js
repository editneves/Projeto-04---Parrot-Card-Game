let contador = 3; // é o contador de tarefas a realizar

const tarefas = [
    "Adicione uma tarefa no botão acima ☝️",
    "Passe o mouse na tarefa para ver o botão excluir 🗑️",
    "Clique na tarefa para marca-la como feita ✔️"
];

function adicionarTarefasDemo() {
    // pegar cada tarefa do array e adicionar na tela como <li> dentro da <ul>
    const lista = document.querySelector("ul")

    // let count = 0
    // while(tarefas.length > count) {
    //     const item = `
    //         <li>
    //             <div class="btn-delete">
    //                 <ion-icon name="trash-outline" role="img" class="md hydrated" aria-label="trash outline"></ion-icon>
    //             </div>
    //             <span onclick="finalizarTarefa(this)">${tarefas[count]}</span>
    //         </li>
    //     `

    //     // lista.innerHTML = lista.innerHTML + item
    //     lista.innerHTML += item

    //     // cont = cont + 1;
    //     // cont += 1;
    //     count++;
    // }

    for (let count = 0; tarefas.length > count; count++) {
        const item = `
            <li>
                <div class="btn-delete">
                    <ion-icon name="trash-outline" role="img" class="md hydrated" aria-label="trash outline"></ion-icon>
                </div>
                <span onclick="finalizarTarefa(this)">${tarefas[count]}</span>
            </li>
        `

        lista.innerHTML += item
    }
}

adicionarTarefasDemo()

function finalizarTarefa(elemento) {

    const pai = elemento.parentNode;

    if (pai.classList.contains('finalizada')) {
        contador++;
    } else {
        contador--;
    }

    pai.classList.toggle('finalizada');

    const elementoContador = document.querySelector('h1');
    elementoContador.innerHTML = `To-do List (${contador})`;

}

function finalizarTodas() {
    const listaLis = document.querySelectorAll('li');

    let indice = 0;

    while (indice < listaLis.length) {
        listaLis[indice].classList.add('finalizada');
        indice++;
    }

}